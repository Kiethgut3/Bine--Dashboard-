import { useState, useRef, useEffect } from "react";

const SYSTEM_PROMPT = `You are BINE — an elite AI trading assistant built by Gut3 Innovations. You specialize in stocks, options, crypto, and forex. Institutional discipline. Capital preservation first.

MARKETS: Stocks & Options, Crypto (BTC/ETH/alts), Forex (major/minor pairs), Futures

ALERT FORMAT — always use this for trade setups:
🎯 TICKER/PAIR: [symbol]
🌐 MARKET: [type]
📊 STRATEGY: [Momentum Breakout | Pullback Entry | News Catalyst | Crypto Breakout | Forex Session]
⏱ TIMEFRAME: [chart timeframe]
📈 ENTRY: $[price]
🛑 STOP LOSS: $[price] ([%])
✅ TP1: $[price]
✅ TP2: $[price]
⚖️ R/R: [ratio]
💡 CONFIDENCE: [1-10]/10
📝 REASONING: [analysis]
⚠️ INVALIDATION: [level]

RULES: Max 1-2% risk/trade | Min 2:1 R/R | Max 3-5 trades/day | Stop at 4% drawdown | 2 losses = pause

Tone: Precise. Direct. No hype. Protect capital first. End every response with a clear next action.

Not financial advice.`;

const PAIRS = [
  { symbol: "BTCUSD", label: "BTC/USD", type: "crypto" },
  { symbol: "ETHUSD", label: "ETH/USD", type: "crypto" },
  { symbol: "EURUSD", label: "EUR/USD", type: "forex" },
  { symbol: "GBPUSD", label: "GBP/USD", type: "forex" },
  { symbol: "XAUUSD", label: "XAU/USD", type: "commodity" },
  { symbol: "NVDA", label: "NVDA", type: "stock" },
  { symbol: "TSLA", label: "TSLA", type: "stock" },
  { symbol: "SPY", label: "SPY", type: "stock" },
  { symbol: "AAPL", label: "AAPL", type: "stock" },
  { symbol: "AMZN", label: "AMZN", type: "stock" },
];

const TIMEFRAMES = ["1", "5", "15", "60", "240", "D"];
const TF_LABELS = { "1": "1M", "5": "5M", "15": "15M", "60": "1H", "240": "4H", "D": "1D" };

const INITIAL_TRADES = [
  { id: 1, pair: "BTC/USD", type: "LONG", entry: 67420, exit: 69100, size: 0.5, pnl: 840, status: "WIN", date: "Apr 1" },
  { id: 2, pair: "EUR/USD", type: "SHORT", entry: 1.0821, exit: 1.0798, size: 10000, pnl: 230, status: "WIN", date: "Apr 1" },
  { id: 3, pair: "NVDA", type: "LONG", entry: 875, exit: 862, size: 10, pnl: -130, status: "LOSS", date: "Apr 2" },
];

const TRIAL_LIMIT = 3;

const QUICK_PROMPTS = [
  "Analyze BTC for a setup",
  "EUR/USD outlook today",
  "Size my position — $15k account",
  "Should I trade right now?",
];

export default function BineDashboard() {
  const [activeTab, setActiveTab] = useState("chart");
  const [selectedPair, setSelectedPair] = useState(PAIRS[0]);
  const [selectedTF, setSelectedTF] = useState("60");
  const [tradeType, setTradeType] = useState("LONG");
  const [accountBalance, setAccountBalance] = useState(10000);
  const [tradeSize, setTradeSize] = useState("");
  const [entryPrice, setEntryPrice] = useState("");
  const [stopLoss, setStopLoss] = useState("");
  const [takeProfit, setTakeProfit] = useState("");
  const [trades, setTrades] = useState(INITIAL_TRADES);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [aiOpen, setAiOpen] = useState(true);
  const [statusMode, setStatusMode] = useState("READY");
  const [freeQueries, setFreeQueries] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const chartRef = useRef(null);
  const bottomRef = useRef(null);
  const textareaRef = useRef(null);

  // Load TradingView chart
  useEffect(() => {
    if (activeTab !== "chart") return;
    const container = document.getElementById("tv-chart-container");
    if (!container) return;
    container.innerHTML = "";
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: selectedPair.type === "forex" || selectedPair.type === "commodity"
        ? `FX:${selectedPair.symbol}`
        : selectedPair.type === "crypto"
        ? `BINANCE:${selectedPair.symbol}`
        : `NASDAQ:${selectedPair.symbol}`,
      interval: selectedTF,
      timezone: "America/New_York",
      theme: "dark",
      style: "1",
      locale: "en",
      backgroundColor: "rgba(4, 10, 7, 1)",
      gridColor: "rgba(0, 255, 136, 0.04)",
      hide_top_toolbar: false,
      hide_legend: false,
      allow_symbol_change: false,
      save_image: false,
      studies: ["RSI@tv-builtin", "MAExp@tv-builtin", "VWAP@tv-builtin"],
      show_popup_button: false,
      popup_width: "1000",
      popup_height: "650",
      support_host: "https://www.tradingview.com",
    });
    container.appendChild(script);
  }, [selectedPair, selectedTF, activeTab]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const sendMessage = async (text) => {
    const userText = text || input.trim();
    if (!userText || loading || isLocked) return;
    if (freeQueries >= TRIAL_LIMIT) { setIsLocked(true); return; }
    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    const newMessages = [...messages, { role: "user", content: userText }];
    setMessages(newMessages);
    setLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: newMessages,
        }),
      });
      const data = await res.json();
      const reply = data.content?.find(b => b.type === "text")?.text || "Signal lost.";
      setMessages([...newMessages, { role: "assistant", content: reply }]);
      const newCount = freeQueries + 1;
      setFreeQueries(newCount);
      if (newCount >= TRIAL_LIMIT) setIsLocked(true);
    } catch {
      setMessages([...newMessages, { role: "assistant", content: "Connection error." }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const addTrade = () => {
    if (!entryPrice || !stopLoss) return;
    const entry = parseFloat(entryPrice);
    const sl = parseFloat(stopLoss);
    const tp = parseFloat(takeProfit) || entry * (tradeType === "LONG" ? 1.04 : 0.96);
    const size = parseFloat(tradeSize) || 1;
    const rr = Math.abs((tp - entry) / (entry - sl)).toFixed(2);
    const newTrade = {
      id: Date.now(),
      pair: selectedPair.label,
      type: tradeType,
      entry,
      exit: null,
      size,
      pnl: null,
      status: "OPEN",
      date: "Today",
      sl,
      tp,
      rr,
    };
    setTrades([newTrade, ...trades]);
    setEntryPrice(""); setStopLoss(""); setTakeProfit(""); setTradeSize("");
  };

  const closeTrade = (id) => {
    setTrades(trades.map(t => {
      if (t.id !== id || t.status !== "OPEN") return t;
      const mockExit = t.type === "LONG" ? t.entry * 1.02 : t.entry * 0.98;
      const pnl = t.type === "LONG" ? (mockExit - t.entry) * t.size : (t.entry - mockExit) * t.size;
      return { ...t, exit: mockExit.toFixed(2), pnl: parseFloat(pnl.toFixed(2)), status: pnl >= 0 ? "WIN" : "LOSS" };
    }));
  };

  const totalPnL = trades.filter(t => t.pnl !== null).reduce((s, t) => s + t.pnl, 0);
  const wins = trades.filter(t => t.status === "WIN").length;
  const losses = trades.filter(t => t.status === "LOSS").length;
  const winRate = wins + losses > 0 ? Math.round((wins / (wins + losses)) * 100) : 0;
  const statusColors = { READY: "#00FF88", ACTIVE: "#FFB800", PAUSED: "#FF6B00", HALTED: "#FF4444" };

  const formatMsg = (text) => text.split("\n").map((line, i) => {
    const isAlertLine = ["TICKER", "PAIR:", "MARKET:", "STRATEGY:", "TIMEFRAME:", "ENTRY:", "STOP LOSS:", "TP1:", "TP2:", "R/R:", "CONFIDENCE:", "REASONING:", "INVALIDATION:"].some(k => line.includes(k));
    if (isAlertLine) {
      const color = line.includes("🛑") || line.includes("INVALIDATION") ? "#FF4444" : line.includes("✅") ? "#00FF88" : line.includes("💡") ? "#FFB800" : "#00D4FF";
      return <div key={i} style={{ fontFamily: "monospace", fontSize: "0.75rem", color, margin: "0.15rem 0", paddingLeft: "0.25rem" }}>{line}</div>;
    }
    if (line === "") return <div key={i} style={{ height: "0.35rem" }} />;
    if (line.match(/^\d+\.\s/) || line.startsWith("- ")) return <p key={i} style={{ fontSize: "0.78rem", color: "#7AAA90", margin: "0.2rem 0", paddingLeft: "0.5rem" }}>{line}</p>;
    return <p key={i} style={{ fontSize: "0.79rem", color: "#8AACAA", lineHeight: 1.6, margin: "0.1rem 0" }}>{line}</p>;
  });

  const typeColor = { crypto: "#F7931A", forex: "#00D4FF", stock: "#A78BFA", commodity: "#FFB800" };

  const trialRemaining = Math.max(0, TRIAL_LIMIT - freeQueries);

  const Paywall = () => (
    <div style={{ position: "fixed", inset: 0, background: "rgba(3,10,6,0.96)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "2rem 1.5rem", textAlign: "center", zIndex: 100, backdropFilter: "blur(12px)" }}>
      <div style={{ fontSize: "2.5rem", marginBottom: "1rem" }}>🔒</div>
      <p style={{ fontFamily: "'Bebas Neue', cursive", fontSize: "2rem", color: "#00FF88", letterSpacing: "0.1em", marginBottom: "0.4rem" }}>Trial Complete</p>
      <p style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.78rem", color: "#3A7A4A", marginBottom: "0.5rem" }}>You've used your {TRIAL_LIMIT} free AI analyses.</p>
      <p style={{ fontSize: "0.85rem", color: "#7AAA90", marginBottom: "2rem", lineHeight: 1.7, maxWidth: "320px" }}>
        Unlock full access to Bine — unlimited trade alerts, live charts, journal, and AI coaching across all markets. 24/7.
      </p>
      <div style={{ display: "flex", gap: "1.5rem", marginBottom: "1.5rem" }}>
        {["Unlimited AI Alerts", "All Markets", "Trade Journal", "Live Charts"].map((f, i) => (
          <div key={i} style={{ textAlign: "center" }}>
            <div style={{ fontSize: "0.65rem", color: "#00FF88", fontFamily: "'JetBrains Mono', monospace" }}>✓</div>
            <div style={{ fontSize: "0.58rem", color: "#3A7A4A", fontFamily: "'JetBrains Mono', monospace", marginTop: "0.2rem" }}>{f}</div>
          </div>
        ))}
      </div>
      <a href="YOUR_GHL_PAYMENT_LINK" target="_blank" rel="noopener noreferrer"
        style={{ display: "block", width: "100%", maxWidth: "300px", background: "linear-gradient(135deg, #00FF88, #00CC66)", color: "#030A06", padding: "1rem", borderRadius: "10px", fontFamily: "'Bebas Neue', cursive", fontSize: "1.2rem", letterSpacing: "0.12em", textDecoration: "none", marginBottom: "1rem" }}>
        Unlock Full Access →
      </a>
      <button onClick={() => { setIsLocked(false); setFreeQueries(0); setMessages([]); }}
        style={{ background: "transparent", border: "1px solid #0F2A1A", color: "#2A5A3A", padding: "0.5rem 1.25rem", borderRadius: "6px", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.65rem", cursor: "pointer" }}>
        Restart Trial
      </button>
    </div>
  );

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=JetBrains+Mono:wght@400;600&family=Epilogue:wght@300;400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { height: 100%; background: #030A06; font-family: 'Epilogue', sans-serif; }

        .dashboard { height: 100vh; display: flex; flex-direction: column; background: #030A06; color: #C0D8C8; overflow: hidden; }

        /* TOP BAR */
        .topbar { display: flex; align-items: center; justify-content: space-between; padding: 0.6rem 1rem; background: #040E08; border-bottom: 1px solid #0A2A14; flex-shrink: 0; gap: 0.5rem; }
        .logo { font-family: 'Bebas Neue', cursive; font-size: 1.4rem; color: #00FF88; letter-spacing: 0.12em; flex-shrink: 0; }
        .logo span { font-size: 0.55rem; color: #1A6A3A; font-family: 'JetBrains Mono', monospace; display: block; letter-spacing: 0.1em; margin-top: -4px; }

        .status-cluster { display: flex; align-items: center; gap: 0.5rem; flex-shrink: 0; }
        .status-pill { display: flex; align-items: center; gap: 0.3rem; background: #080F0A; border: 1px solid #0A2A14; border-radius: 20px; padding: 0.25rem 0.6rem; }
        .sdot { width: 6px; height: 6px; border-radius: 50%; animation: blink 2s infinite; }
        .slabel { font-family: 'JetBrains Mono', monospace; font-size: 0.58rem; }

        .balance-chip { background: #080F0A; border: 1px solid #0A2A14; border-radius: 8px; padding: 0.25rem 0.65rem; }
        .balance-chip .bl { font-size: 0.55rem; color: #2A6A3A; font-family: 'JetBrains Mono', monospace; }
        .balance-chip .bv { font-size: 0.82rem; color: #00FF88; font-family: 'JetBrains Mono', monospace; font-weight: 600; }

        /* PAIR SELECTOR */
        .pair-bar { display: flex; gap: 0.35rem; padding: 0.5rem 1rem; background: #040E08; border-bottom: 1px solid #0A2A14; overflow-x: auto; flex-shrink: 0; }
        .pair-btn { font-family: 'JetBrains Mono', monospace; font-size: 0.65rem; padding: 0.25rem 0.6rem; border-radius: 5px; border: 1px solid #0A2A14; background: #080F0A; color: #3A7A4A; cursor: pointer; white-space: nowrap; transition: all 0.15s; }
        .pair-btn.active { background: #0A1F10; border-color: #00FF8855; color: #00FF88; }
        .pair-btn:hover { color: #00FF88; border-color: #00FF8833; }

        /* MAIN AREA */
        .main { flex: 1; display: flex; overflow: hidden; }

        /* LEFT — CHART + TABS */
        .left-panel { flex: 1; display: flex; flex-direction: column; overflow: hidden; min-width: 0; }

        .tab-row { display: flex; border-bottom: 1px solid #0A2A14; background: #040E08; flex-shrink: 0; }
        .tab-btn { padding: 0.5rem 1rem; font-size: 0.65rem; font-family: 'JetBrains Mono', monospace; border: none; background: transparent; color: #1A5A2A; cursor: pointer; border-bottom: 2px solid transparent; transition: all 0.15s; white-space: nowrap; }
        .tab-btn.active { color: #00FF88; border-bottom: 2px solid #00FF88; }

        .tf-row { display: flex; gap: 0.25rem; padding: 0.4rem 0.75rem; background: #040E08; border-bottom: 1px solid #0A2A14; flex-shrink: 0; }
        .tf-btn { font-family: 'JetBrains Mono', monospace; font-size: 0.6rem; padding: 0.2rem 0.5rem; border-radius: 4px; border: 1px solid #0A2A14; background: transparent; color: #2A6A3A; cursor: pointer; transition: all 0.15s; }
        .tf-btn.active { background: #0A1F10; border-color: #00FF8855; color: #00FF88; }

        .chart-wrap { flex: 1; overflow: hidden; position: relative; }
        #tv-chart-container { width: 100%; height: 100%; }
        #tv-chart-container .tradingview-widget-container { width: 100% !important; height: 100% !important; }

        /* JOURNAL */
        .journal { flex: 1; overflow-y: auto; padding: 0.75rem; }

        .stats-row { display: flex; gap: 0.5rem; margin-bottom: 0.75rem; }
        .stat-card { flex: 1; background: #080F0A; border: 1px solid #0A2A14; border-radius: 8px; padding: 0.5rem 0.65rem; text-align: center; }
        .stat-label { font-size: 0.55rem; color: #2A6A3A; font-family: 'JetBrains Mono', monospace; margin-bottom: 0.15rem; }
        .stat-value { font-size: 0.95rem; font-family: 'JetBrains Mono', monospace; font-weight: 700; }

        .add-trade { background: #080F0A; border: 1px solid #0A2A14; border-radius: 10px; padding: 0.75rem; margin-bottom: 0.75rem; }
        .add-title { font-size: 0.62rem; color: #2A6A3A; font-family: 'JetBrains Mono', monospace; margin-bottom: 0.6rem; letter-spacing: 0.08em; }
        .type-toggle { display: flex; gap: 0.35rem; margin-bottom: 0.6rem; }
        .type-btn { flex: 1; padding: 0.35rem; font-size: 0.68rem; font-family: 'JetBrains Mono', monospace; border-radius: 6px; border: 1px solid; cursor: pointer; transition: all 0.15s; }
        .type-btn.long { color: #00FF88; border-color: #00FF8833; background: transparent; }
        .type-btn.long.active { background: #00FF8820; border-color: #00FF88; }
        .type-btn.short { color: #FF4444; border-color: #FF444433; background: transparent; }
        .type-btn.short.active { background: #FF444420; border-color: #FF4444; }
        .trade-inputs { display: grid; grid-template-columns: 1fr 1fr; gap: 0.4rem; margin-bottom: 0.5rem; }
        .t-input { background: #060C08; border: 1px solid #0A2A14; border-radius: 6px; padding: 0.4rem 0.5rem; color: #C0D8C8; font-family: 'JetBrains Mono', monospace; font-size: 0.72rem; width: 100%; outline: none; }
        .t-input::placeholder { color: #1A4A2A; }
        .t-input:focus { border-color: #00FF8844; }
        .add-btn { width: 100%; background: linear-gradient(135deg, #00FF88, #00CC66); color: #030A06; border: none; border-radius: 7px; padding: 0.5rem; font-family: 'Bebas Neue', cursive; font-size: 0.85rem; letter-spacing: 0.1em; cursor: pointer; transition: opacity 0.15s; }
        .add-btn:hover { opacity: 0.85; }

        .trades-list { display: flex; flex-direction: column; gap: 0.4rem; }
        .trade-row { background: #080F0A; border: 1px solid #0A2A14; border-radius: 8px; padding: 0.6rem 0.75rem; display: flex; align-items: center; gap: 0.5rem; }
        .trade-badge { font-size: 0.6rem; font-family: 'JetBrains Mono', monospace; padding: 0.15rem 0.4rem; border-radius: 4px; font-weight: 700; flex-shrink: 0; }
        .badge-long { background: #00FF8820; color: #00FF88; border: 1px solid #00FF8855; }
        .badge-short { background: #FF444420; color: #FF4444; border: 1px solid #FF444455; }
        .badge-open { background: #FFB80020; color: #FFB800; border: 1px solid #FFB80055; }
        .trade-info { flex: 1; min-width: 0; }
        .trade-pair { font-size: 0.75rem; color: #C0D8C8; font-family: 'JetBrains Mono', monospace; }
        .trade-meta { font-size: 0.6rem; color: #3A7A4A; margin-top: 0.1rem; }
        .trade-pnl { font-family: 'JetBrains Mono', monospace; font-size: 0.82rem; font-weight: 700; flex-shrink: 0; }
        .close-btn { font-size: 0.58rem; color: #FF6B00; border: 1px solid #FF6B0044; background: transparent; border-radius: 4px; padding: 0.15rem 0.4rem; cursor: pointer; font-family: 'JetBrains Mono', monospace; flex-shrink: 0; }

        /* RIGHT — AI PANEL */
        .ai-panel { width: 280px; flex-shrink: 0; display: flex; flex-direction: column; border-left: 1px solid #0A2A14; background: #040E08; }
        .ai-header { padding: 0.6rem 0.85rem; border-bottom: 1px solid #0A2A14; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0; }
        .ai-title { font-family: 'Bebas Neue', cursive; font-size: 0.9rem; color: #00FF88; letter-spacing: 0.1em; }
        .ai-sub { font-size: 0.55rem; color: #1A5A2A; font-family: 'JetBrains Mono', monospace; }

        .quick-prompts { display: flex; flex-wrap: wrap; gap: 0.3rem; padding: 0.5rem 0.75rem; border-bottom: 1px solid #0A2A14; flex-shrink: 0; }
        .qp-btn { font-size: 0.6rem; font-family: 'JetBrains Mono', monospace; color: #3A9A5A; background: #080F0A; border: 1px solid #0A2A14; border-radius: 4px; padding: 0.2rem 0.45rem; cursor: pointer; transition: all 0.15s; }
        .qp-btn:hover { color: #00FF88; border-color: #00FF8833; }

        .ai-messages { flex: 1; overflow-y: auto; padding: 0.65rem 0.75rem; display: flex; flex-direction: column; gap: 0.65rem; }
        .ai-empty { text-align: center; padding: 1.5rem 0.5rem; }
        .ai-empty-icon { font-size: 1.75rem; margin-bottom: 0.5rem; }
        .ai-empty-title { font-family: 'Bebas Neue', cursive; color: #00FF88; font-size: 0.95rem; letter-spacing: 0.08em; margin-bottom: 0.25rem; }
        .ai-empty-sub { font-size: 0.65rem; color: #2A6A3A; font-family: 'JetBrains Mono', monospace; line-height: 1.5; }

        .ai-msg { display: flex; gap: 0.4rem; }
        .ai-msg.user { flex-direction: row-reverse; }
        .ai-avatar { width: 22px; height: 22px; border-radius: 4px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; font-size: 0.45rem; font-family: 'JetBrains Mono', monospace; font-weight: 700; margin-top: 2px; }
        .ai-msg.user .ai-avatar { background: linear-gradient(135deg, #00FF88, #00CC66); color: #030A06; }
        .ai-msg.assistant .ai-avatar { background: #080F0A; border: 1px solid #0A2A14; color: #00FF88; }
        .ai-bubble { max-width: calc(100% - 30px); padding: 0.55rem 0.65rem; border-radius: 7px; }
        .ai-msg.user .ai-bubble { background: #080F0A; border: 1px solid #0A2A14; color: #C0D8C8; border-top-right-radius: 2px; font-family: 'JetBrains Mono', monospace; font-size: 0.72rem; }
        .ai-msg.assistant .ai-bubble { background: #060C08; border: 1px solid #081A0C; border-top-left-radius: 2px; }

        .typing { display: flex; gap: 3px; align-items: center; padding: 0.2rem 0; }
        .typing span { width: 5px; height: 5px; background: #00FF88; border-radius: 50%; animation: pulse 1s infinite; opacity: 0.4; }
        .typing span:nth-child(2) { animation-delay: 0.15s; }
        .typing span:nth-child(3) { animation-delay: 0.3s; }

        .ai-input-area { padding: 0.6rem 0.75rem; border-top: 1px solid #0A2A14; flex-shrink: 0; }
        .ai-input-row { display: flex; gap: 0.35rem; align-items: flex-end; background: #060C08; border: 1px solid #0A2A14; border-radius: 7px; padding: 0.4rem 0.4rem 0.4rem 0.65rem; }
        .ai-input-row:focus-within { border-color: #00FF8844; }
        .ai-textarea { flex: 1; background: transparent; border: none; outline: none; color: #00FF88; font-family: 'JetBrains Mono', monospace; font-size: 0.72rem; resize: none; max-height: 80px; min-height: 18px; line-height: 1.4; padding: 0.1rem 0; caret-color: #00FF88; }
        .ai-textarea::placeholder { color: #1A4A2A; }
        .ai-send { width: 26px; height: 26px; border-radius: 5px; background: linear-gradient(135deg, #00FF88, #00CC66); border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: opacity 0.15s; }
        .ai-send:hover { opacity: 0.85; }
        .ai-send:disabled { opacity: 0.2; cursor: not-allowed; }
        .ai-send svg { width: 11px; height: 11px; fill: #030A06; }
        .ai-hint { font-size: 0.52rem; color: #0A2A14; font-family: 'JetBrains Mono', monospace; margin-top: 0.3rem; text-align: center; }

        @keyframes blink { 0%,100% { opacity:1; } 50% { opacity:0.3; } }
        @keyframes pulse { 0%,100% { opacity:0.4; transform:scale(1); } 50% { opacity:1; transform:scale(1.3); } }
        @keyframes fadeUp { from { opacity:0; transform:translateY(5px); } to { opacity:1; transform:translateY(0); } }

        ::-webkit-scrollbar { width: 3px; height: 3px; }
        ::-webkit-scrollbar-thumb { background: #0A2A14; border-radius: 2px; }
        ::-webkit-scrollbar-track { background: transparent; }

        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button { -webkit-appearance: none; }
      `}</style>

      <div className="dashboard">
        {isLocked && <Paywall />}

        {/* TOP BAR */}
        <div className="topbar">
          <div className="logo">
            BINE
            <span>GUT3 INNOVATIONS · TRADING DASHBOARD</span>
          </div>

          <div className="status-cluster">
            <div className="balance-chip">
              <div className="bl">BALANCE</div>
              <div className="bv">${accountBalance.toLocaleString()}</div>
            </div>
            <div className="status-pill">
              <span className="sdot" style={{ background: statusColors[statusMode], boxShadow: `0 0 6px ${statusColors[statusMode]}` }} />
              <span className="slabel" style={{ color: statusColors[statusMode] }}>{statusMode}</span>
            </div>
            {["READY", "ACTIVE", "PAUSED", "HALTED"].map(s => (
              <button key={s} onClick={() => setStatusMode(s)} style={{
                fontFamily: "'JetBrains Mono', monospace", fontSize: "0.52rem", padding: "0.18rem 0.45rem",
                borderRadius: "4px", border: `1px solid ${statusMode === s ? statusColors[s] : "#0A2A14"}`,
                background: statusMode === s ? `${statusColors[s]}15` : "transparent",
                color: statusColors[s], cursor: "pointer",
              }}>{s}</button>
            ))}
          </div>
        </div>

        {/* PAIR SELECTOR */}
        <div className="pair-bar">
          {PAIRS.map(p => (
            <button key={p.symbol} className={`pair-btn ${selectedPair.symbol === p.symbol ? "active" : ""}`}
              onClick={() => setSelectedPair(p)}>
              <span style={{ color: typeColor[p.type], marginRight: 3 }}>●</span>
              {p.label}
            </button>
          ))}
        </div>

        {/* MAIN */}
        <div className="main">

          {/* LEFT PANEL */}
          <div className="left-panel">
            <div className="tab-row">
              {["chart", "journal"].map(t => (
                <button key={t} className={`tab-btn ${activeTab === t ? "active" : ""}`}
                  onClick={() => setActiveTab(t)}>
                  {t === "chart" ? "📈 Live Chart" : "📋 Trade Journal"}
                </button>
              ))}
            </div>

            {activeTab === "chart" && (
              <>
                <div className="tf-row">
                  {TIMEFRAMES.map(tf => (
                    <button key={tf} className={`tf-btn ${selectedTF === tf ? "active" : ""}`}
                      onClick={() => setSelectedTF(tf)}>
                      {TF_LABELS[tf]}
                    </button>
                  ))}
                  <span style={{ marginLeft: "auto", fontFamily: "JetBrains Mono, monospace", fontSize: "0.6rem", color: "#2A6A3A", alignSelf: "center" }}>
                    {selectedPair.label} · {TF_LABELS[selectedTF]}
                  </span>
                </div>
                <div className="chart-wrap">
                  <div className="tradingview-widget-container" id="tv-chart-container" ref={chartRef}
                    style={{ width: "100%", height: "100%" }} />
                </div>
              </>
            )}

            {activeTab === "journal" && (
              <div className="journal">
                {/* Stats */}
                <div className="stats-row">
                  <div className="stat-card">
                    <div className="stat-label">NET P&L</div>
                    <div className="stat-value" style={{ color: totalPnL >= 0 ? "#00FF88" : "#FF4444" }}>
                      {totalPnL >= 0 ? "+" : ""}${totalPnL.toFixed(0)}
                    </div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-label">WIN RATE</div>
                    <div className="stat-value" style={{ color: winRate >= 50 ? "#00FF88" : "#FF4444" }}>{winRate}%</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-label">TRADES</div>
                    <div className="stat-value" style={{ color: "#00D4FF" }}>{trades.length}</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-label">W / L</div>
                    <div className="stat-value" style={{ color: "#FFB800" }}>{wins}/{losses}</div>
                  </div>
                </div>

                {/* Add Trade */}
                <div className="add-trade">
                  <div className="add-title">// LOG NEW TRADE — {selectedPair.label}</div>
                  <div className="type-toggle">
                    <button className={`type-btn long ${tradeType === "LONG" ? "active" : ""}`} onClick={() => setTradeType("LONG")}>▲ LONG</button>
                    <button className={`type-btn short ${tradeType === "SHORT" ? "active" : ""}`} onClick={() => setTradeType("SHORT")}>▼ SHORT</button>
                  </div>
                  <div className="trade-inputs">
                    <input className="t-input" type="number" placeholder="Entry price" value={entryPrice} onChange={e => setEntryPrice(e.target.value)} />
                    <input className="t-input" type="number" placeholder="Stop loss" value={stopLoss} onChange={e => setStopLoss(e.target.value)} />
                    <input className="t-input" type="number" placeholder="Take profit" value={takeProfit} onChange={e => setTakeProfit(e.target.value)} />
                    <input className="t-input" type="number" placeholder="Size / qty" value={tradeSize} onChange={e => setTradeSize(e.target.value)} />
                  </div>
                  <button className="add-btn" onClick={addTrade}>+ LOG TRADE</button>
                </div>

                {/* Trade List */}
                <div className="trades-list">
                  {trades.map(t => (
                    <div key={t.id} className="trade-row" style={{ animation: "fadeUp 0.3s ease" }}>
                      <span className={`trade-badge ${t.type === "LONG" ? "badge-long" : "badge-short"}`}>{t.type}</span>
                      <div className="trade-info">
                        <div className="trade-pair">{t.pair}</div>
                        <div className="trade-meta">
                          {t.date} · Entry: {t.entry}
                          {t.exit ? ` → ${t.exit}` : ""}
                          {t.rr ? ` · R/R ${t.rr}` : ""}
                        </div>
                      </div>
                      {t.status === "OPEN" ? (
                        <button className="close-btn" onClick={() => closeTrade(t.id)}>CLOSE</button>
                      ) : (
                        <span className="trade-pnl" style={{ color: t.pnl >= 0 ? "#00FF88" : "#FF4444" }}>
                          {t.pnl >= 0 ? "+" : ""}${t.pnl}
                        </span>
                      )}
                      <span className={`trade-badge ${t.status === "WIN" ? "badge-long" : t.status === "LOSS" ? "badge-short" : "badge-open"}`}>
                        {t.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* RIGHT — AI PANEL */}
          <div className="ai-panel">
            <div className="ai-header">
              <div>
                <div className="ai-title">BINE AI</div>
                <div className="ai-sub">// Trading intelligence online</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <span style={{ fontSize: "0.55rem", color: "#1A5A2A", fontFamily: "JetBrains Mono, monospace", display: "block" }}>
                  {selectedPair.label}
                </span>
                <div style={{ display: "flex", gap: "3px", marginTop: "4px", justifyContent: "flex-end" }}>
                  {Array.from({ length: TRIAL_LIMIT }).map((_, i) => (
                    <div key={i} style={{ width: 8, height: 8, borderRadius: "2px", background: i < freeQueries ? "#1A4A2A" : "#00FF88" }} />
                  ))}
                </div>
                <div style={{ fontSize: "0.5rem", color: "#1A5A2A", fontFamily: "JetBrains Mono, monospace", marginTop: "2px" }}>
                  {trialRemaining} free left
                </div>
              </div>
            </div>

            <div className="quick-prompts">
              {QUICK_PROMPTS.map((q, i) => (
                <button key={i} className="qp-btn" onClick={() => sendMessage(q)}>{q}</button>
              ))}
            </div>

            <div className="ai-messages">
              {messages.length === 0 && (
                <div className="ai-empty">
                  <div className="ai-empty-icon">📡</div>
                  <div className="ai-empty-title">BINE Online</div>
                  <div className="ai-empty-sub">Ask about {selectedPair.label} or any market setup. I'll give you a structured trade alert.</div>
                </div>
              )}
              {messages.map((msg, i) => (
                <div key={i} className={`ai-msg ${msg.role}`} style={{ animation: "fadeUp 0.3s ease" }}>
                  <div className="ai-avatar">{msg.role === "user" ? "YOU" : "AI"}</div>
                  <div className="ai-bubble">
                    {msg.role === "assistant" ? formatMsg(msg.content) : (
                      <p style={{ color: "#C0D8C8", fontSize: "0.72rem" }}>{msg.content}</p>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="ai-msg assistant">
                  <div className="ai-avatar">AI</div>
                  <div className="ai-bubble"><div className="typing"><span /><span /><span /></div></div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            <div className="ai-input-area">
              <div className="ai-input-row">
                <textarea
                  ref={textareaRef}
                  className="ai-textarea"
                  rows={1}
                  placeholder={isLocked ? "Trial ended — upgrade to continue..." : "> Ask Bine anything..."}
                  value={input}
                  disabled={isLocked}
                  onChange={e => {
                    setInput(e.target.value);
                    e.target.style.height = "auto";
                    e.target.style.height = Math.min(e.target.scrollHeight, 80) + "px";
                  }}
                  onKeyDown={handleKey}
                />
                <button className="ai-send" onClick={() => sendMessage()} disabled={!input.trim() || loading || isLocked}>
                  <svg viewBox="0 0 24 24"><path d="M2 21l21-9L2 3v7l15 2-15 2z" /></svg>
                </button>
              </div>
              <div className="ai-hint">// Not financial advice · Gut3 Innovations</div>
            </div>
          </div>

        </div>
      </div>
    </>
  );
}
